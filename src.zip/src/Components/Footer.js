export const Footer = ({copyright, company}) => (

<footer className="Footer">

    {copyright} {company}


</footer>

);