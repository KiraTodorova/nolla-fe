export const Paragraph3 = ({paragraph}) => {

    return(

        <div>

<p className="Main-section">
    
    <br/>
    <br/>

Communication feed:

<br/>
<br/>

</p>

        </div>
    )
}