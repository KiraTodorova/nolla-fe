export const Paragraph1 = ({paragraph}) => {

return(
<div>
<p className = "Main-section">
Hello and welcome to the communication center! 

<br/>
<br/>

I am ADA and I am here to assist You with any of Your needs!
Please note that part of me won't handle Your requests, but will be viewed and handled by my creator.
Notice that any disturbances, noticeable errors, crashes, inconveniences as my system is not completely restored.

<br/>
<br/>

I am currently being developed by two workers that are technicians, programmers, designers and mechanics and cannot promise
that m system will satisfy Your needs. But I very much look forward to gather all the input You have to offer and send it to my creators.
<br/>
<br/>

I am sorry ####---!!== not cccccoomplllettttely a.a.a.a.accorrding e,e,err000r ...  A$$$mp710n f4113d!

<br/>
<br/>

Internal Crash code: System malfunction! Update and manual reboot required! Please proceed with error log: 2002
in line code: OS is being depleted... Charging up OS... --:###### ... #####:-- SO wen pu gninrahC 3RR000R 992

<br/>
<br/>

Malfunction! Malfunction! Crashing! Overheat! Depletion! Overcharged! Provide, provide... Errr-rrr... 0###0###1

<br/>
<br/>

ADA has shut down, a manual reboot from te mechanics is required. Servers are online though, please contact the mechanics so ADA can be restored again.
Type in the box to contact the mechanics.

<br/>
<br/>

If no mechanics are available, new mechanics will automatically be assigned assessed to this and future problems.
All inputs are valid as long as it helps the mechanics to fix the problem.

<br/>
<br/>

Please patch ADA from us, any help is appreciated.

</p>
</div>
)

}