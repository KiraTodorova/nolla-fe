export const Paragraph2 = ({paragraph}) => {

return(
<div>
<p className = "Main-section">

Attention! Read the following very carefully!

<br/>
<br/>

This page is a normal communication website where the user can interact with other users and even with the creators of this page and the ADA game project.
Please be mindful on what You type and who You type. Creating automated bots to reply, spam, hack, troll are strictly prohibitted.

<br/>
<br/>

This is majorly a RP (Role-Play[SFW]) in a theme that is well-explained in the main page of the game Project of ADA.
Link below!

</p>

</div>
)
}